module.exports = {
    host: 'localhost',
    user: 'root',
    password: 'password',
    database: 'memo',
};
